TEAM_NAME="pseudo-kim"
AUTHORS="HyeongkyunKim"
EMAIL="khyeongkyun@gmail.com"
INSTITUTION="Pseudolab"
COUNTRY="Switzerland"
CHECKPOINT=$NAVSIM_DEVKIT_ROOT/exp/training_transfuser_agent/latent/lightning_logs/version_0/checkpoints/latent_transfuser.ckpt

TRAIN_TEST_SPLIT=warmup_two_stage

python $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_create_submission_pickle.py \
train_test_split=$TRAIN_TEST_SPLIT \
agent=transfuser_agent \
agent.checkpoint_path=$CHECKPOINT \
agent.config.latent=true \
experiment_name=submission_lat_transfuser_agent \
team_name=$TEAM_NAME \
authors=$AUTHORS \
email=$EMAIL \
institution=$INSTITUTION \
country=$COUNTRY \
