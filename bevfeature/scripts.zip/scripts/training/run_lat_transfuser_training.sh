# trainer.use_cache_without_dataset=true \    for using cache
# trainer.force_cache_computation=false \     for using cache
export HYDRA_FULL_ERROR=1

TRAIN_TEST_SPLIT=navtrain

python $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_training.py \
agent=transfuser_agent \
experiment_name=training_transfuser_agent \
trainer.params.max_epochs=20 \
use_cache_without_dataset=true \
force_cache_computation=false \
train_test_split=$TRAIN_TEST_SPLIT \
agent.config.latent=true \
